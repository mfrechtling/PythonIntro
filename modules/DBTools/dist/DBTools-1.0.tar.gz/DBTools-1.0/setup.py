from setuptools import setup
setup(
        name='DBTools',
        version='1.0',
        description='Managing DB Connections',
        author='Michael Frechtling',
        author_email='michael@frechtling.net',
        url='frechtling.net',
        py_modules=['DBTools'],
        )
