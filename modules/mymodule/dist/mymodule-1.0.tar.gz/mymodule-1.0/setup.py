from setuptools import setup
setup(
        name='mymodule',
        version='1.0',
        description='First python module',
        author='Michael Frechtling',
        author_email='michael@frechtling.net',
        url='someurl.com',
        py_modules=['mymodule']
)
